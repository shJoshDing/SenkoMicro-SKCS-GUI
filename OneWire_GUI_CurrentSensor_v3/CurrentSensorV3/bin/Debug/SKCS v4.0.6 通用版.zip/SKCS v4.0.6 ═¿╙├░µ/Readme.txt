v4.0.5 with single site and multisite supporting, double confirm trim code

different with v4.0.4
1. add delay_sync between singlepath setting,
2. change repower delay time from delay_operation to delay_sync,
3. set M.R.E when spin.

Features:
High precision,
Faster version( ~16s per unit).


v4.0.6 with single site and multisite supporting, double confirm trim code

different with v4.0.5
1. add reconnect buttom in EngTab,
2. For autotrim_singlesite(), add a judgement that if any master bit be trimmed trim agian.
3. binXaccuracy set to double.
4. update PreTrim tab binXaccuracy when start up.